<p>Hi {{ $employee->name }},</p>
<p>
    <b>{{ $emailmessage }}</b>
</p>
<p>
    Please contact admin if you have any query.
</p>
<br>
<p>Thank you.</p>
