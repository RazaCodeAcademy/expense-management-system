<p>Hi {{ $employee->name }},</p>
<p>
    A balance of <b>Rs.{{ $balance }}</b> has been successfully added to your litmus account.
</p>
<p>
    <b>New wallet balance is: Rs.{{ $employee->wallet_balance }}</b>
</p>
<br>
<p>Thank you.</p>
