<p>Hi {{ $employee->name }},</p>
<p>
    Your <b>voucher number {{ $voucher->number }}</b> has been sent for approval.
</p>
<p>
    <b>Please wait while our admin checks the provided data and takes action on your voucher.</b>
</p>
<br>
<p>Thank you.</p>
